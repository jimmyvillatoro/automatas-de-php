<!DOCTYPE html>
<html lang="en">
<head>
<!-- basic -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<!-- mobile metas -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="viewport" content="initial-scale=1, maximum-scale=1"> 
 
<title>Landing</title>
<meta name="keywords" content="">
<meta name="description: formulario Landing" content="">
<meta name="author: Jimmy Villatoro" content="">
<link rel="stylesheet" type="text/css" media="screen" href="style.css" /> 
 
</head>
<!-- body -->
<body> 
 
<p class="centrado">
<img src="images/recepcion1024x700.jpg"  alt="bienvenido"  width="1024" height="700" title="Exposición de Landing page">
 </p>
 

<div class="vfpop">
<h3>Registrarte</h3>
<form action="landing2.php" method="POST"><input type='hidden' name=IdL value='<?php echo utf8_decode($_GET['IdL']); ?>'> 
 
<div><input type='text' name='IdL'  class='form-control' placeholder='IdL' class='form-input' required>
                </div>  
<div><input type='text' name='Nombres'  class='form-control' placeholder='Nombres' class='form-input' required>
                </div>  
<div><input type='text' name='Apellidos'  class='form-control' placeholder='Apellidos' class='form-input' required>
                </div>  
<div><input type='text' name='Correo'  class='form-control' placeholder='Correo' class='form-input' required>
                </div>  
<div><input type='text' name='Movil'  class='form-control' placeholder='Movil' class='form-input' required>
                </div>  
<div><input type='text' name='Msj'  class='form-control' placeholder='Msj' class='form-input' required>
                </div>  
<div><input type='text' name='Fecha'  class='form-control' placeholder='Fecha' class='form-input' required>
                </div>  
<div><input type='text' name='Tipo'  class='form-control' placeholder='Tipo' class='form-input' required>
                </div>  
<div><input type='text' name='Estado'  class='form-control' placeholder='Estado' class='form-input' required>
                </div>  
 
 
<div>
             <button type='submit' class='btn btn-success'>Registrarme</button>
             </div>
             </form>
              </div>
</body>
</html>