<?php 

$servidor  ="localhost"; 
$usuario   ="yaprendo_test";  
$clave     ="us1317mx$";
$basedatos ="yaprendo_ProyectoDan";
$db_connection = mysqli_connect($servidor, $usuario, $clave, $basedatos) or die(mysql_error());
if (!$db_connection) {
	die("No se ha podido conectar a la base de datos");
}else
	echo mysqli_connect_error($db_connection);
	

// sql Crea la tabla usando Lenguaje PHP
$sql = "CREATE TABLE Landing (
IdL INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
Nombres VARCHAR(50) NOT NULL,
Apellidos VARCHAR(50) NOT NULL,
Correo VARCHAR(50),
Movil VARCHAR(20),
Msj VARCHAR(250),
Fecha TIMESTAMP,
Tipo INT(6) ,
Estado INT(6) 
)";

// Se verifica si la tabla ha sido creado
if ($db_connection->query($sql) === TRUE) {
    echo "la tabla Landing ha sido creado";
} else {
    echo "Hubo un error al crear la tabla Landing: " . $conn->error;
}
 
// Cerramos la conexi車n
$db_connection->close();	

 ?>