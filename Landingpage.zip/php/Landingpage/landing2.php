<?php 
include 'db.php'; 
$IdL= $_REQUEST['IdL'];
$Nombres= $_REQUEST['Nombres'];
$Apellidos= $_REQUEST['Apellidos'];
$Correo= $_REQUEST['Correo'];
$Movil= $_REQUEST['Movil'];
$Msj= $_REQUEST['Msj'];
$Fecha= $_REQUEST['Fecha'];
$Tipo= $_REQUEST['Tipo'];
$Estado= $_REQUEST['Estado'];

 
 date_default_timezone_set("America/Mexico_City"); $script_tz = date_default_timezone_get(); $date = date("Y-m-d"); $time = date("H:i:s", time()); $Fecha= $date." ". $time; 
 
 
$resultado=mysqli_query($db_connection, "SELECT * FROM Landing WHERE Nombres LIKE '".$Nombres."'" ); 
 
if (mysqli_num_rows($resultado)>0) {
 
header("Location: index.php?IdL=".$IdL."'");  
 
 
} else {  
 
$insert_value ="INSERT INTO Landing(IdL, Nombres, Apellidos, Correo, Movil, Msj, Fecha, Tipo, Estado) VALUES ( '".$IdL."',  '".$Nombres."',  '".$Apellidos."',  '".$Correo."',  '".$Movil."',  '".$Msj."',  '".$Fecha."',  '".$Tipo."',  '".$Estado."')";


$retry_value = mysqli_query($db_connection,$insert_value);

$cuerpo="#: '".$IdL."' Nombres:'".$Nombres."' Movil: '".$Movil."'  Correo:'".$Correo."' Password: ( ayudar ) Como puedes ayudar? '".$Msj."' ";
mail("jimmyvillatoro77@gmail.com","Prospecto",$cuerpo,"Dale seguimiento");
$resultado=mysqli_query($db_connection, "SELECT IdL  FROM  Landing  WHERE Nombres = '".$Nombres."'" ); 
 
 while ($row =mysqli_fetch_array($resultado))   
$IdL=$row[IdL]; 
 
 header("Location: landing4.php?IdL='".$IdL."'"); 
 
mysqli_free_result($retry_value);
}
mysqli_free_result($resultado);
mysqli_close($db_connection);
?>